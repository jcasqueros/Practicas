package com.santander.peliculacrud.web;

import com.santander.peliculacrud.model.api.ActorRepository;
import com.santander.peliculacrud.model.api.DirectorRepository;
import com.santander.peliculacrud.model.api.FilmRepository;
import com.santander.peliculacrud.model.input.Actor;
import com.santander.peliculacrud.model.input.Director;
import com.santander.peliculacrud.model.input.Film;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/**
 * The type Film controller.
 */
@RestController
@RequestMapping("/film")
public class FilmController {

    private final FilmRepository filmRepository;
    private final ActorRepository actorRepository;
    private final DirectorRepository directorRepository;

    /**
     * Instantiates a new Film controller.
     *
     * @param filmRepository     the film repository
     * @param actorRepository    the actor repository
     * @param directorRepository the director repository
     */
    @Autowired
    public FilmController(FilmRepository filmRepository, ActorRepository actorRepository, DirectorRepository directorRepository) {
        this.filmRepository = filmRepository;
        this.actorRepository = actorRepository;
        this.directorRepository = directorRepository;
    }

    /**
     * Create film string.
     *
     * @param film the film
     * @return the string
     */
    @PostMapping
    public String createFilm(@RequestBody Film film) {
        String message = "Film not created";

            if (filmRepository.existsById(film.getId())) {
                message = "Film already exists";
            } else {

                Director director = directorRepository.findById(film.getDirector().getId()).orElse(null);
                List<Actor> actors = actorRepository.findByIdIn(film.getActorId());

                if (director == null)
                    message = "Director does not exist";
                else {
                    if (actors.isEmpty())
                        message = "Actor does not exist";
                    else {

                        film.setDirector(director);
                        film.setActor(actors);

                        Film savedFilm = filmRepository.save(film);

                        if (savedFilm != null)
                            message = "Film created successfully";
                    }
                }
            }

        return message;
    }

    /**
     * Gets all films.
     *
     * @return the all films
     */
    @GetMapping()
    public List<Film> getAllFilms() {
        return filmRepository.findAll();
    }


    /**
     * Gets film by id.
     *
     * @param id the id
     * @return the film by id
     */
    @GetMapping("/{id}")
    public Film getFilmById(@PathVariable Long id) {
        return filmRepository.findById(id).orElse(null);
    }

    /**
     * Update film string.
     *
     * @param id          the id
     * @param updatedFilm the updated film
     * @return the string
     */
    @PutMapping("/{id}")
    public String updateFilm(@PathVariable Long id, @RequestBody Film updatedFilm) {

        String message = "Film not update";

            if ( !filmRepository.existsById(id)) {
                message = "Film not exists";
            } else {

                Director director = directorRepository.findById(updatedFilm.getDirector().getId()).orElse(null);
                List<Actor> actors = actorRepository.findByIdIn(updatedFilm.getActorId());

                if (director == null)
                    message = "Director does not exist";
                else {

                    if (actors.isEmpty())
                        message = "Actor does not exist";
                    else {

                        updatedFilm.setDirector(director);
                        updatedFilm.setActor(actors);
                        updatedFilm.setId(id);

                        Film savedFilm = filmRepository.save(updatedFilm);

                        if (savedFilm != null)
                            message = "Film update successfully";
                    }
                }

            }

        return message;
    }


    /**
     * Delete film string.
     *
     * @param id the id
     * @return the string
     */
    @DeleteMapping("/{id}")
    public String deleteFilm(@PathVariable Long id) {
        String message = "Film not delete successfully";

        if ( id != null) {

            if (!filmRepository.existsById(id)) {
                message = "Film not found for delete";
            } else {
                filmRepository.deleteById(id);


                if (!filmRepository.existsById(id))
                    message = "Film delete successfully";
            }
        }

        return message;
    }

}
