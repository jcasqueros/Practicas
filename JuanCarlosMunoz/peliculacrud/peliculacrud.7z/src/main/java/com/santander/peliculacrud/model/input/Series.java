package com.santander.peliculacrud.model.input;

import com.santander.peliculacrud.util.CommonOperation;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.List;

/**
 * The type Series.
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Series  {

    @Id
    @GeneratedValue
    private long id;
    private String title;
    private int created;

    @OneToMany
    private List<Actor> actor;

    @ManyToOne
    @OnDelete( action = OnDeleteAction.CASCADE )
    private Director director;

    /**
     * Get actor id list.
     *
     * @return the list
     */
    public List<Long> getActorId(){
        CommonOperation commonOperation = new CommonOperation();
        return commonOperation.getListIde(this.actor);
    }



}
