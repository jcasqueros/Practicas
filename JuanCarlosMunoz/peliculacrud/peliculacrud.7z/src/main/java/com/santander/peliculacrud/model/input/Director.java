package com.santander.peliculacrud.model.input;

import com.santander.peliculacrud.util.Nation;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Director.
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Director {

    @Id
    @GeneratedValue
    private long id;
    private String name;
    private int age;
    private Nation nation;




}
