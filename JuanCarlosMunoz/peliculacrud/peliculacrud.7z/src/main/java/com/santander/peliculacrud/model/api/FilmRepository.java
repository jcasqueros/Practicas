package com.santander.peliculacrud.model.api;

import com.santander.peliculacrud.model.input.Film;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * The interface Film repository.
 */
public interface FilmRepository extends JpaRepository<Film, Long> {


    Optional<Film> findById(Long id);


    List<Film> findAll();


    <S extends Film> S save(S film);


    void deleteById(Long id);


    boolean existsById(Long id);


    /**
     * Exists by director id boolean.
     *
     * @param id the id
     * @return the boolean
     */
    boolean existsByDirectorId(Long id);

}