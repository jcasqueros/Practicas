package com.santander.peliculacrud.model.api;

import com.santander.peliculacrud.model.input.Actor;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * The interface Actor repository.
 */
@Repository
public interface ActorRepository extends JpaRepository<Actor, Long> {


    /**
     * Find by name list.
     *
     * @param name the name
     * @return the list
     */
    List<Actor> findByName(String name);

    Optional<Actor> findById(Long id);


    List<Actor> findAll();


    <S extends Actor> S save(S actor);


    void deleteById(Long id);


    boolean existsById(Long id);

    /**
     * Find by id in list.
     *
     * @param ids the ids
     * @return the list
     */
    List<Actor> findByIdIn(List<Long > ids);

}
