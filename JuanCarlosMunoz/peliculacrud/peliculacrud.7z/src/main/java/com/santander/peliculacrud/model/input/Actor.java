package com.santander.peliculacrud.model.input;

import com.santander.peliculacrud.util.Nation;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Actor.
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table
public class Actor {

    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private int age;
    private Nation nation;




}
