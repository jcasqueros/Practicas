package com.santander.peliculacrud.util;

public enum Nation {

    ESP("Spain"),
    ING("England"),
    FRA("France"),
    POR("Portugal"),
    IT("Italy"),
    GER("Germany"),
    BRA("Brazil"),
    EEUU("United States"),
    ;

    private final String nation;

    private Nation(String nation) {
        this.nation = nation;
    }

    public String getNation() {return nation;}
}
