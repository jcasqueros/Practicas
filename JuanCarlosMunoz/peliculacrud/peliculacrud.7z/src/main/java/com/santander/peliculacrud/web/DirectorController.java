package com.santander.peliculacrud.web;

import com.santander.peliculacrud.model.api.DirectorRepository;
import com.santander.peliculacrud.model.input.Director;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The type Director controller.
 */
@RestController
@RequestMapping("/directors")
public class DirectorController {

    private final DirectorRepository directorRepository;

    /**
     * Instantiates a new Director controller.
     *
     * @param directorRepository the director repository
     */
    @Autowired
    public DirectorController(DirectorRepository directorRepository) {
        this.directorRepository = directorRepository;
    }

    /**
     * Create director string.
     *
     * @param director the director
     * @return the string
     */
    @PostMapping
    public String createDirector(@RequestBody Director director) {
        String message = "Director not created";
        Director savedDirector = directorRepository.save(director);

        if (savedDirector != null)
            message = "Director created successfully";

        return message;
    }

    /**
     * Gets all directors.
     *
     * @return the all directors
     */
    @GetMapping()
    public List<Director> getAllDirectors() {
        return directorRepository.findAll();
    }


    /**
     * Gets director by id.
     *
     * @param id the id
     * @return the director by id
     */
    @GetMapping("/{id}")
    public Director getDirectorById(@PathVariable Long id) {
        return directorRepository.findById(id).orElse(null);
    }

    /**
     * Update director string.
     *
     * @param id              the id
     * @param updatedDirector the updated director
     * @return the string
     */
    @PutMapping("/{id}")
    public String updateDirector(@PathVariable Long id, @RequestBody Director updatedDirector) {
        String message = "Director not update";

        if (!directorRepository.existsById(id)) {
            message = "Director not found for update";
        } else {

            updatedDirector.setId(id);
            Director savedDirector = directorRepository.save(updatedDirector);

            if (savedDirector != null)
                message = "Director updated successfully";
        }


        return message;
    }


    /**
     * Delete director string.
     *
     * @param id the id
     * @return the string
     */
    @DeleteMapping("/{id}")
    public String deleteDirector(@PathVariable Long id) {
        String message = "Director not delete";

        if (id != null) {
            if (!directorRepository.existsById(id)) {
                message = "Director not found for delete";
            } else {
                directorRepository.deleteById(id);


                if (!directorRepository.existsById(id))
                    message = "Director updated successfully";
            }
        }

        return message;
    }


}
