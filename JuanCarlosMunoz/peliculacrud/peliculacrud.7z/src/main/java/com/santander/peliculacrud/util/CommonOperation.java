package com.santander.peliculacrud.util;

import com.santander.peliculacrud.model.input.Actor;

import java.util.ArrayList;
import java.util.List;

public class CommonOperation {

    public List<Long> getListIde(List<Actor> actors){
        List<Long> actorIds = new ArrayList<>();
        for(Actor actor : actors)
            actorIds.add(actor.getId());
        return actorIds;
    }

}
