package com.santander.peliculacrud.model.api;

import com.santander.peliculacrud.model.input.Film;
import com.santander.peliculacrud.model.input.Series;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * The interface Series repository.
 */
public interface SeriesRepository extends JpaRepository<Series, Long> {


    Optional<Series> findById(Long id);


    List<Series> findAll();


    /**
     * Save s.
     *
     * @param <S>    the type parameter
     * @param series the series
     * @return the s
     */
    <S extends Film> S save(S series);


    void deleteById(Long id);


    boolean existsById(Long id);


    /**
     * Exists by director id boolean.
     *
     * @param id the id
     * @return the boolean
     */
    boolean existsByDirectorId(Long id);
}