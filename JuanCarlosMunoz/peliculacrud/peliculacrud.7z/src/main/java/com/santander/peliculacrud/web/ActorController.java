package com.santander.peliculacrud.web;

import com.santander.peliculacrud.model.api.ActorRepository;
import com.santander.peliculacrud.model.input.Actor;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * The type Actor controller.
 */
@RestController
@RequestMapping("/actors")
public class ActorController {


    private final ActorRepository actorRepository;

    /**
     * Instantiates a new Actor controller.
     *
     * @param actorRepository the actor repository
     */
    @Autowired
    public ActorController(ActorRepository actorRepository) {
        this.actorRepository = actorRepository;
    }

    /**
     * Create actor string.
     *
     * @param actor the actor
     * @return the string
     */
    @PostMapping
    public String createActor(@RequestBody Actor actor) {

        String message = "Actor not created";

        Actor savedActor = actorRepository.save(actor);

        if (savedActor != null)
            message = "Actor created successfully";

        return message;
    }

    /**
     * Gets all actors.
     *
     * @return the all actors
     */
    @GetMapping()
    public List<Actor> getAllActors() {
        return actorRepository.findAll();
    }


    /**
     * Gets actor by id.
     *
     * @param id the id
     * @return the actor by id
     */
    @GetMapping("/{id}")
    public Actor getActorById(@PathVariable Long id) {
        return actorRepository.findById(id).orElse(null);
    }

    /**
     * Update actor string.
     *
     * @param id           the id
     * @param updatedActor the updated actor
     * @return the string
     */
    @PutMapping("/{id}")
    public String updateActor(@PathVariable Long id, @RequestBody Actor updatedActor) {
        String message = "User not update";

        if (!actorRepository.existsById(id)) {
            message = "Actor not found for update";
        } else {
            updatedActor.setId(id);
            Actor savedActor = actorRepository.save(updatedActor);

            if (savedActor != null)
                message = "Actor updated successfully";

        }

        return message;
    }


    /**
     * Delete actor string.
     *
     * @param id the id
     * @return the string
     */
    @DeleteMapping("/{id}")
    public String deleteActor(@PathVariable Long id) {
        String message = "User not delete";

        if (id != null) {
            if (!actorRepository.existsById(id)) {
                message = "Actor not found for delete";
            } else {
                actorRepository.deleteById(id);


                if (!actorRepository.existsById(id))
                    message = "Actor updated successfully";
            }
        }

        return message;
    }

}
