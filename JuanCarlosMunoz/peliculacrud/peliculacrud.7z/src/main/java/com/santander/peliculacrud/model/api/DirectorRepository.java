package com.santander.peliculacrud.model.api;

import com.santander.peliculacrud.model.input.Director;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * The interface Director repository.
 */
public interface DirectorRepository extends JpaRepository<Director, Long> {

    /**
     * Find by name list.
     *
     * @param name the name
     * @return the list
     */
    List<Director> findByName(String name);

    Optional<Director> findById(Long id);


    List<Director> findAll();


    <S extends Director> S save(S director);


    void deleteById(Long id);


    boolean existsById(Long id);
}
