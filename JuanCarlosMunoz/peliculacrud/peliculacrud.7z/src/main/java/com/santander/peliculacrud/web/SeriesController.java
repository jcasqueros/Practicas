package com.santander.peliculacrud.web;

import com.santander.peliculacrud.model.api.ActorRepository;
import com.santander.peliculacrud.model.api.DirectorRepository;
import com.santander.peliculacrud.model.api.SeriesRepository;
import com.santander.peliculacrud.model.input.Actor;
import com.santander.peliculacrud.model.input.Director;
import com.santander.peliculacrud.model.input.Series;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/series")
public class SeriesController {
    private final SeriesRepository seriesRepository;
    private final ActorRepository actorRepository;
    private final DirectorRepository directorRepository;


    @Autowired
    public SeriesController(SeriesRepository seriesRepository, ActorRepository actorRepository, DirectorRepository directorRepository) {
        this.seriesRepository = seriesRepository;
        this.actorRepository = actorRepository;
        this.directorRepository = directorRepository;
    }

    @PostMapping
    public String createSeries(@RequestBody Series series) {
        String message = "Series not created";

        if ( !seriesRepository.existsById(series.getId())) {

            Director director = directorRepository.findById(series.getDirector().getId()).orElse(null);
            List<Actor> actors = actorRepository.findByIdIn(series.getActorId());

            if (director == null)
                message = "Director does not exist";
            else {

                if (actors.isEmpty())
                    message = "Actor does not exist";
                else {

                    series.setDirector(director);
                    series.setActor(actors);

                    seriesRepository.save(series);

                    message = "Series created successfully";
                }
            }
        }


        return message;
    }

    @GetMapping()
    public List<Series> getAllSeries() {
        return seriesRepository.findAll();
    }


    @GetMapping("/{id}")
    public Series getSeriesById(@PathVariable Long id) {
        return seriesRepository.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    public String updateSeries(@PathVariable Long id, @RequestBody Series updatedSeries) {

        String message = "Series not update";


        if (!seriesRepository.existsById(id)) {
            message = "Series not exists";
        } else {

            Director director = directorRepository.findById(updatedSeries.getDirector().getId()).orElse(null);
            List<Actor> actors = actorRepository.findByIdIn(updatedSeries.getActorId());

            if (director == null)
                message = "Director does not exist";
            else {

                if (actors.isEmpty())
                    message = "Actor does not exist";
                else {

                    updatedSeries.setDirector(director);
                    updatedSeries.setActor(actors);
                    updatedSeries.setId(id);

                    seriesRepository.save(updatedSeries);

                    message = "Series update successfully";
                }
            }

        }
        return message;
    }


    @DeleteMapping("/{id}")
    public String deleteSeries(@PathVariable Long id) {
        String message = "Series not delete successfully";
        if (id != null) {
            if (!seriesRepository.existsById(id)) {
                message = "Series not found for delete";
            } else {
                seriesRepository.deleteById(id);


                if (!seriesRepository.existsById(id))
                    message = "Series delete successfully";
            }
        }

        return message;
    }

}
