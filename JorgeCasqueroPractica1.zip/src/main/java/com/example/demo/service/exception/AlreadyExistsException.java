package com.example.demo.service.exception;

public class AlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public AlreadyExistsException(String mensaje) {
		super(mensaje);
	}

}
