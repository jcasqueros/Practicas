package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Usuario;
import com.example.demo.service.exception.AlreadyExistsException;
import com.example.demo.service.exception.NotFoundException;

public interface UsuarioService {
	// ListarUsuarios → retorna todos los usuarios.
	List<Usuario> getAll();

//	ListarUsuario → retorna un usuario por un dni dado.
	Usuario getByDni(String dni) throws NotFoundException;

	// AñadirUsuario → comprobará si un usuario es válido. Si lo es y no existe en
	// la base de datos, lo añadirá a la base de datos y si no, lanzará una
	// excepción.
	Usuario save(Usuario usuario) throws AlreadyExistsException;

//	ModificarUsuario → comprobará si un usuario es válido. Si lo es y  existe en la base de datos, modificará el usuario existente y si no, lanzará una excepción. 
	boolean update(Usuario usuario,String dni);

//	Eliminar un usuario → eliminará un usuario dado un dni
	void delete(String dni);
}
