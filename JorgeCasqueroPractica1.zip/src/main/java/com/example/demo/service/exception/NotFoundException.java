package com.example.demo.service.exception;

public class NotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5075099918710612164L;

	/**
	 * 
	 */
	public NotFoundException(String mensaje) {
		super(mensaje);
	}

}
