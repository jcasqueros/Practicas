package com.example.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Usuario;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.service.UsuarioService;
import com.example.demo.service.exception.AlreadyExistsException;
import com.example.demo.service.exception.NotFoundException;

@Service
public class UsuarioServiceImpl implements UsuarioService {

	@Autowired
	UsuarioRepository usuarioRepository;

	@Override
	public List<Usuario> getAll() {

		return usuarioRepository.findAll();
	}

	@Override
	public Usuario getByDni(String dni) throws NotFoundException {
		return usuarioRepository.findById(dni)
				.orElseThrow(() -> new NotFoundException("no se ha encontrado el usuario con dni" + dni));
	}

	@Override
	public Usuario save(Usuario usuario) throws AlreadyExistsException {

		if (usuarioRepository.existsById(usuario.getDni())) {
			throw new AlreadyExistsException("El usuario con dni " + usuario.getDni() + " ya esta en la tabla");
		} else {
			return usuarioRepository.save(usuario);
		}
	}

	@Override
	public boolean update(Usuario usuario, String dni) {
		boolean update = false;
		if (usuarioRepository.existsById(dni)) {

			Optional<Usuario> user = usuarioRepository.findById(dni);
			Usuario aux = user.get();
			aux.setName(usuario.getName());
			aux.setSurname(usuario.getSurname());
			aux.setAge(usuario.getAge());
			update = true;
		}

		return update;
	}

	@Override
	public void delete(String dni) {
		if (usuarioRepository.existsById(dni)) {
			usuarioRepository.deleteById(dni);
		}

	}

}
