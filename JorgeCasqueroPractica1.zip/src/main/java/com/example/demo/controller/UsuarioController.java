package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Usuario;
import com.example.demo.service.UsuarioService;
import com.example.demo.service.exception.AlreadyExistsException;
import com.example.demo.service.exception.NotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/user")
public class UsuarioController {
	@Autowired
	UsuarioService usuarioService;

	@GetMapping("/getAll")
	public List<Usuario> getAll() {
		return usuarioService.getAll();
	}

	@GetMapping("/get/{dni}")
	public Usuario getOne(@PathVariable String dni) throws NotFoundException {
		return usuarioService.getByDni(dni);
	}

	@PutMapping("/modify/{dni}")
	public String modify(@RequestBody Usuario usuario, @PathVariable String dni) {
		
		if (usuarioService.update(usuario, dni)) {
			
		}
		;
		return "usuario modificado";
	}

	@PostMapping("/save")
	public String save(@RequestBody Usuario usuario) throws AlreadyExistsException {
		usuarioService.save(usuario);

		return "Se ha añadido con exito";
	}

}
