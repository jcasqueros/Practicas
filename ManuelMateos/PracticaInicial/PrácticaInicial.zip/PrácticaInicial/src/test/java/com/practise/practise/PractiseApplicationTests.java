package com.practise.practise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PractiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
